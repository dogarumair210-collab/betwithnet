/**
 * Bet With Net - Aztec Sun Wheel of Fortune Game Engine
 * Exact Sun Wheel / Fortune Gems 2 Standalone Theme, Physics & Animation Engine
 * Incorporates 3D Coin Rain, Big Win Shield, Web Audio Synthesizer & HD Sound FX
 */

class SlotAudioEngine {
    constructor() {
        this.ctx = null;
        this.isMuted = false;
        try {
            this.audioTick = new Audio('../assets/games/wheel/audio/wheel_tick.mp3');
            this.audioSpin = new Audio('../assets/games/wheel/audio/wheel_spin.mp3');
            this.audioWin = new Audio('../assets/games/wheel/audio/win.mp3');
            this.audioChip = new Audio('../assets/games/wheel/audio/chip_place.mp3');
            [this.audioTick, this.audioSpin, this.audioWin, this.audioChip].forEach(a => {
                if (a) {
                    a.volume = 0.55;
                    a.load();
                }
            });
        } catch (e) {
            console.warn('Audio FX preload warning:', e);
        }
    }

    init() {
        if (!this.ctx) {
            const AudioCtx = window.AudioContext || window.webkitAudioContext;
            if (AudioCtx) this.ctx = new AudioCtx();
        }
        if (this.ctx && this.ctx.state === 'suspended') {
            this.ctx.resume();
        }
    }

    toggleMute() {
        this.isMuted = !this.isMuted;
        const icon = document.getElementById('muteIcon');
        if (icon) icon.innerText = this.isMuted ? '🔇' : '🔊';
        return this.isMuted;
    }

    playSpinStart() {
        if (this.isMuted) return;
        this.init();
        try {
            if (this.audioSpin) {
                this.audioSpin.currentTime = 0;
                const p = this.audioSpin.play();
                if (p && typeof p.catch === 'function') p.catch(() => {});
            }
        } catch (e) {}

        if (!this.ctx) return;
        try {
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(140, now);
            osc.frequency.exponentialRampToValueAtTime(420, now + 0.28);
            gain.gain.setValueAtTime(0.25, now);
            gain.gain.exponentialRampToValueAtTime(0.01, now + 0.32);
            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start(now);
            osc.stop(now + 0.32);
        } catch (e) {}
    }

    playTick() {
        if (this.isMuted) return;
        try {
            if (this.audioTick) {
                const tick = this.audioTick.cloneNode();
                tick.volume = 0.45;
                const p = tick.play();
                if (p && typeof p.catch === 'function') p.catch(() => {});
                return;
            }
        } catch (e) {}

        if (!this.ctx) this.init();
        if (!this.ctx) return;
        try {
            const now = this.ctx.currentTime;
            const osc = this.ctx.createOscillator();
            const gain = this.ctx.createGain();
            osc.type = 'sine';
            osc.frequency.setValueAtTime(260, now);
            osc.frequency.exponentialRampToValueAtTime(70, now + 0.06);
            gain.gain.setValueAtTime(0.3, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.07);
            osc.connect(gain);
            gain.connect(this.ctx.destination);
            osc.start(now);
            osc.stop(now + 0.07);
        } catch (e) {}
    }

    playWinLine(count = 1) {
        if (this.isMuted) return;
        this.init();
        try {
            if (this.audioWin) {
                this.audioWin.currentTime = 0;
                const p = this.audioWin.play();
                if (p && typeof p.catch === 'function') p.catch(() => {});
            }
        } catch (e) {}

        if (!this.ctx) return;
        try {
            const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
            notes.forEach((freq, idx) => {
                const now = this.ctx.currentTime + (idx * 0.08);
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'triangle';
                osc.frequency.setValueAtTime(freq, now);
                gain.gain.setValueAtTime(0.3, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
                osc.connect(gain);
                gain.connect(this.ctx.destination);
                osc.start(now);
                osc.stop(now + 0.25);
            });
        } catch (e) {}
    }

    playBigWinFanfare() {
        if (this.isMuted) return;
        this.init();
        try {
            if (this.audioWin) {
                this.audioWin.currentTime = 0;
                const p = this.audioWin.play();
                if (p && typeof p.catch === 'function') p.catch(() => {});
            }
        } catch (e) {}

        if (!this.ctx) return;
        try {
            const melody = [523.25, 523.25, 523.25, 659.25, 783.99, 1046.50, 1318.51];
            melody.forEach((freq, idx) => {
                const now = this.ctx.currentTime + (idx * 0.12);
                const osc = this.ctx.createOscillator();
                const gain = this.ctx.createGain();
                osc.type = 'square';
                osc.frequency.setValueAtTime(freq, now);
                gain.gain.setValueAtTime(0.2, now);
                gain.gain.exponentialRampToValueAtTime(0.001, now + 0.35);
                osc.connect(gain);
                gain.connect(this.ctx.destination);
                osc.start(now);
                osc.stop(now + 0.35);
            });
        } catch (e) {}
    }
}

class AztecSunWheelGame {
    constructor() {
        this.discEl = null;
        this.pointerGlowEl = null;
        this.sunGlowEl = null;
        this.resultEl = null;
        this.spinBtn = null;
        this.bigWinModal = null;
        this.bigWinAmountEl = null;

        this.baseBet = 100;
        this.isExtraBet = false;
        this.isTurbo = false;
        this.isAuto = false;
        this.autoCount = 0;
        this.isSpinning = false;
        this.angle = 0; // Cumulative rotation degrees

        this.audio = new SlotAudioEngine();

        // 20 segments on the Aztec Sun Wheel
        // Starting at 0° (top / 12 o'clock pointer)
        this.segments = [
            { mult: 2.0, label: 'x2', name: '2x Double Sun', weight: 22 },
            { mult: 3.0, label: 'x3', name: '3x Aztec Treasure', weight: 18 },
            { mult: 5.0, label: 'x5', name: '5x Fortune Flame', weight: 14 },
            { mult: 8.0, label: 'x8', name: '8x Emerald Glory', weight: 10 },
            { mult: 20.0, label: 'x20', name: '20x Ruby Mega', weight: 5 },
            { mult: 15.0, label: 'x15', name: '15x Amethyst Hit', weight: 6 },
            { mult: 10.0, label: 'x10', name: '10x Sapphire Prize', weight: 8 },
            { mult: 40.0, label: 'x40', name: '40x Jade Jackpot', weight: 2 },
            { mult: 10.0, label: 'x10', name: '10x Temple Gold', weight: 8 },
            { mult: 10.0, label: 'x10', name: '10x Solar Ray', weight: 8 },
            { mult: 8.0, label: 'x8', name: '8x Serpentine Win', weight: 10 },
            { mult: 20.0, label: 'x20', name: '20x Turquoise Strike', weight: 5 },
            { mult: 20.0, label: 'x20', name: '20x Mystic Orb', weight: 5 },
            { mult: 10.0, label: 'x10', name: '10x Golden Idol', weight: 8 },
            { mult: 30.0, label: 'x30', name: '30x Celestial Burst', weight: 3 },
            { mult: 50.0, label: 'x50', name: '50x Sun Emperor', weight: 1.8 },
            { mult: 100.0, label: '100x', name: '100X MEGA SUN JACKPOT', weight: 1.0 },
            { mult: 0.0, label: '0x', name: '0x Sun Shadow', weight: 8 },
            { mult: 5.0, label: 'x5', name: '5x Solar Flame', weight: 14 },
            { mult: 10.0, label: 'x10', name: '10x Sun Guardian', weight: 8 }
        ];

        // 3D Coin Rain particle system
        this.coins = [];
        this.coinCanvas = null;
        this.cCtx = null;
        this.cW = 0;
        this.cH = 0;
    }

    init() {
        this.discEl = document.getElementById('aztec-wheel-disc');
        this.pointerGlowEl = document.getElementById('aztec-pointer-glow');
        this.sunGlowEl = document.getElementById('aztec-center-sun-glow');
        this.resultEl = document.getElementById('wheel-result-display');
        this.spinBtn = document.getElementById('spinButton');
        this.bigWinModal = document.getElementById('bigWinModal');
        this.bigWinAmountEl = document.getElementById('bigWinAmount');

        if (this.discEl) {
            this.discEl.style.transform = `rotate(${this.angle}deg)`;
            this.discEl.style.webkitTransform = `rotate(${this.angle}deg)`;
        }

        // Initialize 3D Coin Rain
        this.coinCanvas = document.getElementById('coinRainCanvas');
        if (this.coinCanvas) {
            this.cCtx = this.coinCanvas.getContext('2d');
            this.resizeCoinCanvas();
            window.addEventListener('resize', () => this.resizeCoinCanvas());
            this.coinRainLoop = this.coinRainLoop.bind(this);
            requestAnimationFrame(this.coinRainLoop);
        }

        this.syncUI();
    }

    resizeCoinCanvas() {
        if (!this.coinCanvas) return;
        this.cW = this.coinCanvas.width = window.innerWidth;
        this.cH = this.coinCanvas.height = window.innerHeight;
    }

    emitCoins(count = 70) {
        if (!this.coinCanvas) return;
        for (let i = 0; i < count; i++) {
            this.coins.push({
                x: Math.random() * this.cW,
                y: -30 - Math.random() * 250,
                size: 13 + Math.random() * 13,
                vy: 5 + Math.random() * 8,
                vx: (Math.random() - 0.5) * 3.5,
                rot: Math.random() * Math.PI * 2,
                vrot: (Math.random() - 0.5) * 0.28
            });
        }
    }

    coinRainLoop() {
        if (this.cCtx) {
            this.cCtx.clearRect(0, 0, this.cW, this.cH);
            for (let i = this.coins.length - 1; i >= 0; i--) {
                const c = this.coins[i];
                c.y += c.vy;
                c.x += c.vx;
                c.rot += c.vrot;
                const sy = Math.cos(c.rot);

                this.cCtx.save();
                this.cCtx.translate(c.x, c.y);
                this.cCtx.scale(1, Math.abs(sy));
                this.cCtx.beginPath();
                this.cCtx.arc(0, 0, c.size, 0, Math.PI * 2);
                this.cCtx.fillStyle = '#ffd700';
                this.cCtx.fill();
                this.cCtx.lineWidth = 2.5;
                this.cCtx.strokeStyle = '#b8860b';
                this.cCtx.stroke();
                
                // Inner rim ring
                this.cCtx.beginPath();
                this.cCtx.arc(0, 0, c.size * 0.65, 0, Math.PI * 2);
                this.cCtx.strokeStyle = 'rgba(255, 245, 166, 0.7)';
                this.cCtx.lineWidth = 1.2;
                this.cCtx.stroke();
                
                this.cCtx.restore();

                if (c.y > this.cH + 50) this.coins.splice(i, 1);
            }
        }
        requestAnimationFrame(this.coinRainLoop);
    }

    syncUI() {
        const cost = this.isExtraBet ? Math.round(this.baseBet * 1.5) : this.baseBet;
        const bal = window.wallet ? window.wallet.getBalance() : 10000;

        const balEl = document.getElementById('userBalance');
        if (balEl) balEl.innerText = window.wallet ? window.wallet.formatAmount(bal) : '₨' + bal.toLocaleString();

        const betEl = document.getElementById('betAmount');
        if (betEl) betEl.innerText = '₨' + cost.toLocaleString();

        const baseBetEl = document.getElementById('baseBetDisplay');
        if (baseBetEl) baseBetEl.innerText = '₨' + this.baseBet.toLocaleString();

        const betInput = document.getElementById('wheel-bet-input');
        if (betInput) betInput.value = this.baseBet;
    }

    adjustBet(delta) {
        if (this.isSpinning) return;
        const bets = [10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000];
        let idx = bets.indexOf(this.baseBet);
        if (idx === -1) idx = 3;
        idx = Math.max(0, Math.min(bets.length - 1, idx + delta));
        this.baseBet = bets[idx];
        this.audio.playTick();
        this.syncUI();
    }

    setBet(val) {
        if (this.isSpinning) return;
        this.baseBet = Math.max(10, Math.min(50000, parseFloat(val) || 100));
        this.audio.playTick();
        this.syncUI();
    }

    toggleExtraBet() {
        if (this.isSpinning) return;
        this.isExtraBet = !this.isExtraBet;
        const btn = document.getElementById('extraBetToggle');
        if (btn) btn.classList.toggle('active', this.isExtraBet);
        this.audio.playTick();
        this.syncUI();
    }

    toggleTurbo() {
        this.isTurbo = !this.isTurbo;
        const btn = document.getElementById('turboToggle');
        if (btn) btn.classList.toggle('active', this.isTurbo);
        this.audio.playTick();
    }

    toggleAutoSpin() {
        const btn = document.getElementById('autoSpinToggle');
        if (this.isAuto) {
            this.isAuto = false;
            this.autoCount = 0;
            if (btn) {
                btn.classList.remove('active');
                btn.innerHTML = `<span>🔄</span> Auto`;
            }
        } else {
            this.isAuto = true;
            this.autoCount = 20;
            if (btn) {
                btn.classList.add('active');
                btn.innerHTML = `<span>🔄</span> Auto (${this.autoCount})`;
            }
            if (!this.isSpinning) this.executeSpin();
        }
    }

    flashPointer() {
        if (!this.pointerGlowEl) return;
        this.pointerGlowEl.style.opacity = '1';
        this.pointerGlowEl.style.transform = 'translate(-50%, -50%) scale(1.4)';
        setTimeout(() => {
            if (this.isSpinning && this.pointerGlowEl) {
                this.pointerGlowEl.style.opacity = '0';
                this.pointerGlowEl.style.transform = 'translate(-50%, -50%) scale(1)';
            }
        }, 60);
    }

    async executeSpin() {
        if (this.isSpinning) return;
        this.audio.init();

        const cost = this.isExtraBet ? Math.round(this.baseBet * 1.5) : this.baseBet;

        // Auto-seed demo balance if user has insufficient funds for smooth local testing
        if (window.wallet) {
            if (window.wallet.getBalance() < cost) {
                window.wallet.addBalancePKR(10000);
                if (window.core && typeof window.core.updateAllBalances === 'function') {
                    window.core.updateAllBalances();
                }
                if (window.app && window.app.showToast) {
                    window.app.showToast('🎁 Added ₨10,000 Demo Balance!', 'info');
                }
            }
            try {
                window.wallet.placeBet(cost, 'Aztec Sun Wheel');
                if (window.core && typeof window.core.updateAllBalances === 'function') {
                    window.core.updateAllBalances();
                }
            } catch (err) {
                console.warn('Wallet placeBet error:', err);
            }
        }

        this.isSpinning = true;
        this.syncUI();

        const winValEl = document.getElementById('lastWinAmount');
        if (winValEl) winValEl.innerText = '₨0';

        if (this.spinBtn) {
            this.spinBtn.classList.add('spinning');
            this.spinBtn.disabled = true;
        }

        if (this.resultEl) {
            this.resultEl.className = 'aztec-result-text';
            this.resultEl.innerHTML = `☀️ SUN WHEEL IS SPINNING... ☀️`;
        }

        if (this.sunGlowEl) {
            this.sunGlowEl.classList.add('active');
        }

        this.audio.playSpinStart();

        // Weighted outcome calculation
        // If Extra Bet active, eliminate 0x and boost high multipliers
        let pool = this.segments;
        if (this.isExtraBet) {
            pool = this.segments.map(s => {
                if (s.mult === 0) return { ...s, weight: 0 };
                if (s.mult >= 20) return { ...s, weight: s.weight * 1.8 };
                return s;
            });
        }

        const totalWeight = pool.reduce((acc, s) => acc + s.weight, 0);
        let rand = Math.random() * totalWeight;
        let targetIndex = 0;
        for (let i = 0; i < pool.length; i++) {
            if (rand < pool[i].weight) {
                targetIndex = i;
                break;
            }
            rand -= pool[i].weight;
        }

        // Each segment is 18° (360° / 20)
        const segDegrees = 18;
        const targetDeg = targetIndex * segDegrees;
        const targetOffset = (360 - targetDeg) % 360;

        // Organic jitter within sector [-4, +4]
        const jitter = (Math.random() - 0.5) * 8;

        // 6 to 9 full spins
        const extraSpins = (this.isTurbo ? 4 : (6 + Math.floor(Math.random() * 3))) * 360;

        // Cumulative angle calculation
        const currentRot = ((this.angle % 360) + 360) % 360;
        const deltaAngle = extraSpins + ((targetOffset - currentRot + 360) % 360) + jitter;
        const finalAngle = this.angle + deltaAngle;

        const duration = this.isTurbo ? 2200 : 4500; // ms
        const startTime = performance.now();
        const startAngle = this.angle;
        let lastTickAngle = startAngle;

        return new Promise(resolve => {
            const step = (now) => {
                const elapsed = now - startTime;
                const progress = Math.min(elapsed / duration, 1);

                // Precise ease-out kinematics
                const easeOut = 1 - Math.pow(1 - progress, 3.8);
                this.angle = startAngle + easeOut * (finalAngle - startAngle);

                if (this.discEl) {
                    this.discEl.style.transform = `rotate(${this.angle}deg)`;
                    this.discEl.style.webkitTransform = `rotate(${this.angle}deg)`;
                }

                // Audio tick & pointer flash on every segment boundary crossed
                if (Math.abs(this.angle - lastTickAngle) >= segDegrees) {
                    lastTickAngle = this.angle;
                    this.audio.playTick();
                    this.flashPointer();
                }

                if (progress < 1) {
                    requestAnimationFrame(step);
                } else {
                    this.finishSpin(targetIndex, cost);
                    resolve();
                }
            };
            requestAnimationFrame(step);
        });
    }

    finishSpin(index, totalBet) {
        this.isSpinning = false;
        if (this.spinBtn) {
            this.spinBtn.classList.remove('spinning');
            this.spinBtn.disabled = false;
        }

        if (this.sunGlowEl) {
            this.sunGlowEl.classList.remove('active');
        }

        const seg = this.segments[index];
        const payout = Math.round(totalBet * seg.mult * 100) / 100;

        // Keep pointer illuminated on win
        if (this.pointerGlowEl) {
            this.pointerGlowEl.classList.add('active');
            setTimeout(() => {
                if (this.pointerGlowEl) this.pointerGlowEl.classList.remove('active');
            }, 3000);
        }

        // Payout to wallet
        if (window.wallet) {
            try {
                window.wallet.creditWin(totalBet, payout, 'Aztec Sun Wheel', seg.mult, `Hit: ${seg.label} (${seg.name})`);
                if (window.core && typeof window.core.updateAllBalances === 'function') {
                    window.core.updateAllBalances();
                }
            } catch (e) {
                console.warn('Wallet creditWin error:', e);
            }
        }

        this.syncUI();

        const winValEl = document.getElementById('lastWinAmount');
        if (winValEl) {
            winValEl.innerText = window.wallet ? window.wallet.formatAmount(payout) : '₨' + payout.toLocaleString();
        }

        if (seg.mult > 0) {
            const isBig = seg.mult >= 20;

            if (this.resultEl) {
                this.resultEl.className = `aztec-result-text ${isBig ? 'big-win' : 'win'}`;
                const formattedPayout = window.wallet ? window.wallet.formatAmount(payout) : '₨' + payout.toLocaleString();
                this.resultEl.innerHTML = isBig
                    ? `🔥 EPIC AZTEC SUN WIN: ${seg.label}! WON ${formattedPayout} 🔥`
                    : `✨ WINNER: ${seg.label}! PAYOUT: ${formattedPayout} ✨`;
            }

            if (isBig) {
                this.audio.playBigWinFanfare();
                this.emitCoins(110);
                this.showBigWinModal(payout);
            } else {
                this.audio.playWinLine();
                this.emitCoins(45);
            }

            if (window.app && window.app.showToast) {
                const formattedPayout = window.wallet ? window.wallet.formatAmount(payout) : '₨' + payout.toLocaleString();
                window.app.showToast(`Aztec Sun Wheel: Hit ${seg.label}! Won ${formattedPayout}`, 'success');
            }
        } else {
            if (this.resultEl) {
                this.resultEl.className = 'aztec-result-text';
                this.resultEl.innerHTML = `☀️ 0x - The Sun Temple will favor your next spin! ☀️`;
            }
            if (window.app && window.app.showToast) {
                window.app.showToast('0x - Try again for the Sun Jackpot!', 'info');
            }
        }

        // Auto spin loop
        if (this.isAuto && this.autoCount > 0) {
            this.autoCount--;
            const btn = document.getElementById('autoSpinToggle');
            if (btn) btn.innerHTML = `<span>🔄</span> Auto (${this.autoCount})`;
            if (this.autoCount <= 0) {
                this.isAuto = false;
                if (btn) {
                    btn.classList.remove('active');
                    btn.innerHTML = `<span>🔄</span> Auto`;
                }
            } else {
                setTimeout(() => {
                    if (this.isAuto) this.executeSpin();
                }, this.isTurbo ? 350 : 800);
            }
        }
    }

    showBigWinModal(amount) {
        if (!this.bigWinModal) return;
        const formatted = window.wallet ? window.wallet.formatAmount(amount) : '₨' + amount.toLocaleString();
        if (this.bigWinAmountEl) this.bigWinAmountEl.innerText = formatted;
        this.bigWinModal.classList.add('show');
        setTimeout(() => {
            if (this.bigWinModal) this.bigWinModal.classList.remove('show');
        }, 3200);
    }
}

// Global instance
window.wheelGame = new AztecSunWheelGame();
window.audio = window.wheelGame.audio;

// Helper global proxies
function adjustBet(delta) { if (window.wheelGame) window.wheelGame.adjustBet(delta); }
function toggleExtraBet() { if (window.wheelGame) window.wheelGame.toggleExtraBet(); }
function toggleTurbo() { if (window.wheelGame) window.wheelGame.toggleTurbo(); }
function toggleAutoSpin() { if (window.wheelGame) window.wheelGame.toggleAutoSpin(); }
function executeSpin() { if (window.wheelGame) window.wheelGame.executeSpin(); }
function spinBonusWheel() { if (window.wheelGame) window.wheelGame.executeSpin(); }
