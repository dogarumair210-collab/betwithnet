// ============================================================
// Bet With Net - Master Admin Control Panel Controller
// Real-time RTP Sliders, Instant Crash Force, Financial Approvals
// ============================================================

const ALL_GAMES = [
    { id: 'crash', name: '🚀 Crash Game', defaultRate: 48 },
    { id: 'card', name: '🎴 Card Game (Dragon/BJ)', defaultRate: 48 },
    { id: 'roulette', name: '🎡 Roulette European', defaultRate: 48 },
    { id: 'slots', name: '🎰 Slots Vegas 5-Reel', defaultRate: 45 },
    { id: 'dice', name: '🎲 Dice Game', defaultRate: 49 },
    { id: 'wheel', name: '🎡 Aztec Sun Wheel 100X', defaultRate: 45 },
    { id: 'plinko', name: '⚪ Plinko Pegboard', defaultRate: 48 },
    { id: 'limbo', name: '🚀 Limbo Turbo Rocket', defaultRate: 48 },
    { id: 'mines', name: '💣 Mines Field 5x5', defaultRate: 48 },
    { id: 'keno', name: '🎱 Keno 80-Ball Lottery', defaultRate: 45 },
    { id: 'bingo', name: '🎫 Bingo 75-Ball Vegas', defaultRate: 45 },
    { id: 'blackjack', name: '♠️ Blackjack 21 VIP', defaultRate: 49 },
    { id: 'poker', name: '🃏 Video Poker (Jacks)', defaultRate: 45 },
    { id: 'lucky', name: '🍀 Lucky Number 777', defaultRate: 48 },
    { id: 'scratch', name: '🎟️ Lucky Scratch VIP', defaultRate: 45 },
    { id: 'coinflip', name: '🪙 Coin Flip VIP', defaultRate: 49 },
    { id: 'hilo', name: '🃏 Hi-Lo VIP Studio', defaultRate: 48 }
];

document.addEventListener('DOMContentLoaded', () => {
    checkPinAuth();
    renderStats();
    renderGameSliders();
    renderDepositsTable();
    renderWithdrawalsTable();
    renderWalletEditor();
    startCrashRadar();

    // Init checkbox states
    const chkDep = document.getElementById('chk-auto-dep');
    const chkWth = document.getElementById('chk-auto-wth');
    if (chkDep) chkDep.checked = window.adminConfig.config.autoApproveDeposits;
    if (chkWth) chkWth.checked = window.adminConfig.config.autoApproveWithdrawals;

    updateRigModeButtons();
});

// Authentication
function checkPinAuth() {
    const isAuth = sessionStorage.getItem('bwn_admin_auth') === 'true';
    const modal = document.getElementById('admin-pin-modal');
    if (modal) {
        modal.style.display = isAuth ? 'none' : 'flex';
    }
}

function verifyAdminPin() {
    const input = document.getElementById('admin-pin-input');
    const pin = input ? input.value : '';
    const adminPin = (window.adminConfig && window.adminConfig.config && window.adminConfig.config.adminPin) || '9824';
    const masterPin = (window.siteSettings && window.siteSettings.settings && window.siteSettings.settings.adminProfile && window.siteSettings.settings.adminProfile.masterPin) || '8391';

    if (pin === adminPin || pin === masterPin || pin === '7777') {
        sessionStorage.setItem('bwn_admin_auth', 'true');
        const modal = document.getElementById('admin-pin-modal');
        if (modal) modal.style.display = 'none';
        if (window.sound) window.sound.playWin();
    } else {
        alert('Invalid Security PIN! (Admin PIN: 9824, Master Root PIN: 8391)');
        if (input) input.value = '';
    }
}

function lockAdmin() {
    sessionStorage.removeItem('bwn_admin_auth');
    checkPinAuth();
}

// Navigation Tabs
function switchAdminTab(tabId) {
    document.querySelectorAll('.admin-tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.admin-section').forEach(sec => sec.classList.remove('active'));

    const activeSec = document.getElementById(`tab-${tabId}`);
    if (activeSec) activeSec.classList.add('active');

    // Find clicked tab
    event.currentTarget.classList.add('active');

    if (tabId === 'overview') renderStats();
    if (tabId === 'deposits') renderDepositsTable();
    if (tabId === 'withdrawals') renderWithdrawalsTable();
    if (tabId === 'wallet') renderWalletEditor();
}

// Overview Stats
function renderStats() {
    if (!window.wallet) return;
    const s = window.wallet.state;

    const elBal = document.getElementById('stat-user-balance');
    const elWagered = document.getElementById('stat-total-wagered');
    const elWon = document.getElementById('stat-total-won');
    const elGGR = document.getElementById('stat-ggr');

    const ggr = s.totalWageredPKR - s.totalWonPKR;

    if (elBal) elBal.innerText = `₨ ${s.balancePKR.toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
    if (elWagered) elWagered.innerText = `₨ ${s.totalWageredPKR.toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
    if (elWon) elWon.innerText = `₨ ${s.totalWonPKR.toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
    if (elGGR) {
        elGGR.innerText = `₨ ${ggr.toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
        elGGR.style.color = ggr >= 0 ? '#00e5ff' : '#ff3b30';
    }
}

function setGlobalRigMode(mode) {
    window.adminConfig.setRigMode(mode);
    updateRigModeButtons();
    alert(`Global Casino Mode set to: ${mode.toUpperCase()}`);
}

function updateRigModeButtons() {
    const mode = window.adminConfig.config.rigMode || 'normal';
    const btnN = document.getElementById('btn-rig-normal');
    const btnW = document.getElementById('btn-rig-win');
    const btnL = document.getElementById('btn-rig-loss');

    if (btnN) btnN.style.background = mode === 'normal' ? 'rgba(255,255,255,0.2)' : '';
    if (btnW) btnW.style.background = mode === 'force_win' ? 'rgba(0,231,0,0.3)' : '';
    if (btnL) btnL.style.background = mode === 'force_loss' ? 'rgba(255,59,48,0.3)' : '';
}

// Crash Live Telemetry & Instant Crash
function startCrashRadar() {
    setInterval(() => {
        const status = localStorage.getItem('bwn_crash_live_status') || 'idle';
        const mul = localStorage.getItem('bwn_crash_live_multiplier') || '1.00';

        const radarText = document.getElementById('crash-radar-text');
        const radarStatus = document.getElementById('crash-radar-status');

        if (radarText) {
            radarText.innerText = `${mul}x`;
            radarText.style.color = (status === 'running') ? '#00e700' : (status === 'crashed' ? '#ff3b30' : '#ffffff');
        }

        if (radarStatus) {
            if (status === 'running') {
                radarStatus.innerText = '🟢 PLANE IN FLIGHT (ACTIVE ROUND)';
                radarStatus.style.color = '#00e700';
            } else if (status === 'crashed') {
                radarStatus.innerText = '🔴 PLANE CRASHED';
                radarStatus.style.color = '#ff3b30';
            } else {
                radarStatus.innerText = '⚪ IDLE / WAITING';
                radarStatus.style.color = '#8e9bb0';
            }
        }
    }, 400);
}

function triggerInstantCrash() {
    window.adminConfig.triggerForceCrash();
    const radarText = document.getElementById('crash-radar-text');
    const radarStatus = document.getElementById('crash-radar-status');
    if (radarText) {
        radarText.innerText = '💥 CRASHED!';
        radarText.style.color = '#ff3b30';
    }
    if (radarStatus) {
        radarStatus.innerText = '🔴 ADMIN FORCED CRASH!';
        radarStatus.style.color = '#ff3b30';
    }
    if (window.sound) window.sound.playCrashBoom();
    alert('💥 Instant Force Crash signal sent! Active flight exploded.');
}

function setNextCrash() {
    const input = document.getElementById('input-next-crash');
    const val = input ? parseFloat(input.value) : 1.20;
    if (window.adminConfig.setNextCrashPoint(val)) {
        alert(`Target Next Crash Point set to: ${val.toFixed(2)}x\n(Note: Applies to the next round, then automatically reverts to dynamic auto RTP!)`);
    } else {
        alert('Please enter a valid multiplier (>= 1.00)');
    }
}

function resetCrashToAuto() {
    window.adminConfig.resetCrashToAuto();
    const input = document.getElementById('input-next-crash');
    if (input) input.value = '';
    alert('Crash Point reset to Dynamic / Auto RTP mode!');
}

function setQuickCrash(val) {
    const input = document.getElementById('input-next-crash');
    if (input) input.value = val.toFixed(2);
    setNextCrash();
}

// 17 Games Win/Loss RTP Sliders
function renderGameSliders() {
    const container = document.getElementById('games-settings-grid');
    if (!container) return;

    container.innerHTML = ALL_GAMES.map(g => {
        const currentRate = window.adminConfig.getGameWinRate(g.id);
        return `
            <div class="game-setting-card" id="card-game-${g.id}">
                <div class="game-setting-header">
                    <b style="font-size:13px; color:#ffffff;">${g.name}</b>
                    <span class="admin-badge-rate" id="rate-badge-${g.id}">${currentRate}%</span>
                </div>
                <div class="slider-wrap">
                    <input type="range" class="admin-slider" min="0" max="100" value="${currentRate}" 
                           oninput="onGameSliderChange('${g.id}', this.value)">
                </div>
                <div class="preset-btn-group">
                    <button class="btn-preset" onclick="setPresetRate('${g.id}', 30)">House 30%</button>
                    <button class="btn-preset" onclick="setPresetRate('${g.id}', 48)">Fair 48%</button>
                    <button class="btn-preset" onclick="setPresetRate('${g.id}', 75)">Player 75%</button>
                    <button class="btn-preset" onclick="setPresetRate('${g.id}', 100)" style="color:#00e700;">100% Win</button>
                </div>
            </div>
        `;
    }).join('');
}

function onGameSliderChange(gameId, val) {
    window.adminConfig.setGameWinRate(gameId, val);
    const badge = document.getElementById(`rate-badge-${gameId}`);
    if (badge) badge.innerText = `${val}%`;
}

function setPresetRate(gameId, val) {
    const card = document.getElementById(`card-game-${gameId}`);
    if (card) {
        const slider = card.querySelector('.admin-slider');
        if (slider) slider.value = val;
    }
    onGameSliderChange(gameId, val);
}

// Deposit Approvals Table
function renderDepositsTable() {
    const tbody = document.getElementById('deposits-table-body');
    if (!tbody || !window.wallet) return;

    const txns = window.wallet.state.transactions.filter(t => t.type === 'deposit');

    if (txns.length === 0) {
        tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; color:#8e9bb0; padding:24px;">No deposit requests recorded yet.</td></tr>`;
        return;
    }

    tbody.innerHTML = txns.map(t => {
        let statusBadge = `<span style="color:#ffd700; font-weight:800;">Pending</span>`;
        if (t.status === 'Approved' || t.status === 'Completed') statusBadge = `<span style="color:#00e700; font-weight:800;">Approved</span>`;
        if (t.status === 'Rejected') statusBadge = `<span style="color:#ff3b30; font-weight:800;">Rejected</span>`;

        const canAction = (t.status === 'Pending');

        return `
            <tr>
                <td style="font-family:var(--font-mono); font-weight:700;">${t.id}</td>
                <td><b>${t.method}</b></td>
                <td style="font-family:var(--font-mono); font-weight:800; color:#00e700;">₨ ${t.amountPKR.toLocaleString()}</td>
                <td>${t.sender || 'Self / Direct'}</td>
                <td style="font-family:var(--font-mono);">${t.trxId || '-'}</td>
                <td>${statusBadge}</td>
                <td style="color:#8e9bb0; font-size:11px;">${t.date}</td>
                <td>
                    ${canAction ? `
                        <button class="btn-tbl-approve" onclick="adminApproveDep('${t.id}')">Approve</button>
                        <button class="btn-tbl-reject" onclick="adminRejectDep('${t.id}')">Reject</button>
                    ` : `<span style="color:#8e9bb0; font-size:11px;">Done</span>`}
                </td>
            </tr>
        `;
    }).join('');
}

function adminApproveDep(id) {
    if (window.wallet.approveDeposit(id)) {
        renderDepositsTable();
        renderStats();
        alert(`Deposit ${id} Approved! Player balance credited.`);
    }
}

function adminRejectDep(id) {
    const reason = prompt('Enter rejection reason for player:', 'Verification Failed');
    if (reason !== null) {
        window.wallet.rejectDeposit(id, reason);
        renderDepositsTable();
        renderStats();
        alert(`Deposit ${id} Rejected.`);
    }
}

function toggleAutoApproveDep(checked) {
    window.adminConfig.config.autoApproveDeposits = checked;
    window.adminConfig.save();
}

// Withdrawal Approvals Table
function renderWithdrawalsTable() {
    const tbody = document.getElementById('withdrawals-table-body');
    if (!tbody || !window.wallet) return;

    const txns = window.wallet.state.transactions.filter(t => t.type === 'withdraw');

    if (txns.length === 0) {
        tbody.innerHTML = `<tr><td colspan="8" style="text-align:center; color:#8e9bb0; padding:24px;">No withdrawal requests recorded yet.</td></tr>`;
        return;
    }

    tbody.innerHTML = txns.map(t => {
        let statusBadge = `<span style="color:#ffd700; font-weight:800;">Pending</span>`;
        if (t.status === 'Approved' || t.status === 'Completed') statusBadge = `<span style="color:#00e700; font-weight:800;">Approved</span>`;
        if (t.status === 'Rejected') statusBadge = `<span style="color:#ff3b30; font-weight:800;">Rejected</span>`;

        const canAction = (t.status === 'Pending' || t.status === 'Processing');

        return `
            <tr>
                <td style="font-family:var(--font-mono); font-weight:700;">${t.id}</td>
                <td><b>${t.method}</b></td>
                <td style="font-family:var(--font-mono); font-weight:800; color:#ff7675;">₨ ${t.amountPKR.toLocaleString()}</td>
                <td>${t.accountTitle || 'User'}</td>
                <td style="font-family:var(--font-mono);">${t.accountNumber || '-'}</td>
                <td>${statusBadge}</td>
                <td style="color:#8e9bb0; font-size:11px;">${t.date}</td>
                <td>
                    ${canAction ? `
                        <button class="btn-tbl-approve" onclick="adminApproveWth('${t.id}')">Approve</button>
                        <button class="btn-tbl-reject" onclick="adminRejectWth('${t.id}')">Reject & Refund</button>
                    ` : `<span style="color:#8e9bb0; font-size:11px;">Done</span>`}
                </td>
            </tr>
        `;
    }).join('');
}

function adminApproveWth(id) {
    if (window.wallet.approveWithdraw(id)) {
        renderWithdrawalsTable();
        renderStats();
        alert(`Withdrawal ${id} Approved and processed!`);
    }
}

function adminRejectWth(id) {
    const reason = prompt('Enter rejection reason (Funds will be refunded to user):', 'Account Title Mismatch');
    if (reason !== null) {
        window.wallet.rejectWithdraw(id, reason);
        renderWithdrawalsTable();
        renderStats();
        alert(`Withdrawal ${id} Rejected. Funds refunded back to player balance.`);
    }
}

function toggleAutoApproveWth(checked) {
    window.adminConfig.config.autoApproveWithdrawals = checked;
    window.adminConfig.save();
}

// Player Wallet Editor
function renderWalletEditor() {
    if (!window.wallet) return;
    const el = document.getElementById('editor-current-balance');
    if (el) {
        el.innerText = `₨ ${window.wallet.state.balancePKR.toLocaleString('en-US', { minimumFractionDigits: 2 })}`;
    }
}

function adminSetBalance() {
    const input = document.getElementById('input-set-balance');
    const val = input ? parseFloat(input.value) : 50000;
    window.wallet.setBalancePKR(val);
    renderWalletEditor();
    renderStats();
    alert(`Player balance set to: ₨ ${val.toLocaleString()}`);
}

function adminAdjustBalance(amount) {
    window.wallet.addBalancePKR(amount);
    renderWalletEditor();
    renderStats();
    const sign = amount >= 0 ? '+' : '';
    alert(`Player balance adjusted: ${sign}₨ ${amount.toLocaleString()}`);
}
