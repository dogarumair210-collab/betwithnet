/**
 * Bet With Net - Pragmatic Play American Blackjack Engine
 * Fully integrated with Bet With Net WalletEngine & authentic 52 high-res cards,
 * chips, action buttons, table shoe, and payouts.
 */

class PragmaticBlackjackEngine {
    constructor() {
        this.baseAssetPath = '../assets/games/blackjack/';
        
        this.suits = [
            { symbol: '♠', name: 'spades' },
            { symbol: '♣', name: 'clubs' },
            { symbol: '♦', name: 'diamonds' },
            { symbol: '♥', name: 'hearts' }
        ];
        this.ranks = [
            { symbol: '2', name: '2', value: 2 },
            { symbol: '3', name: '3', value: 3 },
            { symbol: '4', name: '4', value: 4 },
            { symbol: '5', name: '5', value: 5 },
            { symbol: '6', name: '6', value: 6 },
            { symbol: '7', name: '7', value: 7 },
            { symbol: '8', name: '8', value: 8 },
            { symbol: '9', name: '9', value: 9 },
            { symbol: '10', name: '10', value: 10 },
            { symbol: 'J', name: 'jack', value: 10 },
            { symbol: 'Q', name: 'queen', value: 10 },
            { symbol: 'K', name: 'king', value: 10 },
            { symbol: 'A', name: 'ace', value: 11 }
        ];

        this.deckCount = 8;
        this.shoe = [];
        this.selectedChip = 500;
        this.currency = 'PKR';
        this.localBalance = 50000;

        this.lastBets = { 0: 0, 1: 0, 2: 0 };
        this.currentBets = { 0: 0, 1: 0, 2: 0 };
        this.insuranceBets = { 0: 0, 1: 0, 2: 0 };

        this.dealerCards = [];
        this.playerHands = {
            0: [], // spot 0
            1: [], // spot 1 (center)
            2: []  // spot 2
        };

        this.activeSpots = [];
        this.currentTurnIndex = 0;
        this.gameState = 'BETTING'; // 'BETTING', 'DEALING', 'INSURANCE_OFFER', 'PLAYER_TURN', 'DEALER_TURN', 'ROUND_OVER'
        this.dealerHoleHidden = true;

        this.initShoe();
        this.initAudio();
        this.initWallet();
    }

    // --- Audio System (Web Audio API Synthesizer) ---
    initAudio() {
        this.soundEnabled = true;
        this.audioCtx = null;
    }

    ensureAudio() {
        if (!this.audioCtx) {
            const AudioContext = window.AudioContext || window.webkitAudioContext;
            if (AudioContext) {
                this.audioCtx = new AudioContext();
            }
        }
        if (this.audioCtx && this.audioCtx.state === 'suspended') {
            this.audioCtx.resume();
        }
    }

    toggleSound() {
        this.soundEnabled = !this.soundEnabled;
        const btn = document.getElementById('bj-sound-btn');
        if (btn) btn.innerText = this.soundEnabled ? '🔊' : '🔇';
        return this.soundEnabled;
    }

    playCardDeal() {
        if (!this.soundEnabled) return;
        this.ensureAudio();
        if (!this.audioCtx) return;
        const now = this.audioCtx.currentTime;
        const bufferSize = this.audioCtx.sampleRate * 0.08;
        const buffer = this.audioCtx.createBuffer(1, bufferSize, this.audioCtx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
            data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (bufferSize * 0.25));
        }
        const noise = this.audioCtx.createBufferSource();
        noise.buffer = buffer;
        const filter = this.audioCtx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(1400, now);
        filter.Q.setValueAtTime(2.5, now);
        const gain = this.audioCtx.createGain();
        gain.gain.setValueAtTime(0.3, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
        noise.connect(filter);
        filter.connect(gain);
        gain.connect(this.audioCtx.destination);
        noise.start(now);
    }

    playChip() {
        if (!this.soundEnabled) return;
        this.ensureAudio();
        if (!this.audioCtx) return;
        const now = this.audioCtx.currentTime;
        const osc = this.audioCtx.createOscillator();
        const gain = this.audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(2200, now);
        osc.frequency.exponentialRampToValueAtTime(600, now + 0.05);
        gain.gain.setValueAtTime(0.35, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
        osc.connect(gain);
        gain.connect(this.audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.05);
    }

    playWin() {
        if (!this.soundEnabled) return;
        this.ensureAudio();
        if (!this.audioCtx) return;
        const notes = [523.25, 659.25, 783.99, 1046.50];
        notes.forEach((freq, idx) => {
            const now = this.audioCtx.currentTime + (idx * 0.08);
            const osc = this.audioCtx.createOscillator();
            const gain = this.audioCtx.createGain();
            osc.type = 'triangle';
            osc.frequency.setValueAtTime(freq, now);
            gain.gain.setValueAtTime(0.3, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.25);
            osc.connect(gain);
            gain.connect(this.audioCtx.destination);
            osc.start(now);
            osc.stop(now + 0.25);
        });
    }

    playBlackjack() {
        if (!this.soundEnabled) return;
        this.ensureAudio();
        if (!this.audioCtx) return;
        const chords = [523.25, 659.25, 783.99, 1046.50, 1318.51];
        chords.forEach((freq, idx) => {
            const now = this.audioCtx.currentTime + (idx * 0.07);
            const osc = this.audioCtx.createOscillator();
            const gain = this.audioCtx.createGain();
            osc.type = 'sawtooth';
            osc.frequency.setValueAtTime(freq, now);
            gain.gain.setValueAtTime(0.25, now);
            gain.gain.exponentialRampToValueAtTime(0.001, now + 0.4);
            osc.connect(gain);
            gain.connect(this.audioCtx.destination);
            osc.start(now);
            osc.stop(now + 0.4);
        });
    }

    playBust() {
        if (!this.soundEnabled) return;
        this.ensureAudio();
        if (!this.audioCtx) return;
        const now = this.audioCtx.currentTime;
        const osc = this.audioCtx.createOscillator();
        const gain = this.audioCtx.createGain();
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(260, now);
        osc.frequency.exponentialRampToValueAtTime(80, now + 0.28);
        gain.gain.setValueAtTime(0.3, now);
        gain.gain.exponentialRampToValueAtTime(0.001, now + 0.28);
        osc.connect(gain);
        gain.connect(this.audioCtx.destination);
        osc.start(now);
        osc.stop(now + 0.28);
    }

    // --- Bet With Net Wallet Engine Integration ---
    initWallet() {
        if (window.wallet) {
            this.currency = window.wallet.state ? window.wallet.state.currency || 'PKR' : 'PKR';
            if (window.wallet.on) {
                window.wallet.on('balanceChanged', () => this.syncBalanceFromWallet());
            }
        }
        this.syncBalanceFromWallet();
    }

    syncBalanceFromWallet() {
        if (window.wallet && window.wallet.state) {
            this.currency = window.wallet.state.currency || 'PKR';
            if (this.currency === 'USD') {
                this.localBalance = Number(window.wallet.state.balanceUSD || 0);
            } else {
                this.localBalance = Number(window.wallet.state.balancePKR || 0);
            }
            if (this.localBalance <= 0) {
                // Faucet for guest / test play
                this.localBalance = 50000;
            }
        }
        this.updateUI();
    }

    getBalance() {
        return this.localBalance;
    }

    deductBalance(amount) {
        this.localBalance -= amount;
        if (window.wallet && typeof window.wallet.placeBet === 'function') {
            try {
                window.wallet.placeBet(amount, 'American Blackjack 21');
            } catch (e) {}
        }
    }

    addBalance(amount, betRef, isWin) {
        this.localBalance += amount;
        if (window.wallet && typeof window.wallet.settleBet === 'function') {
            try {
                window.wallet.settleBet(betRef || 0, isWin, amount, { game: 'American Blackjack 21' });
            } catch (e) {}
        }
    }

    // --- Shoe & Card Mechanics ---
    initShoe() {
        this.shoe = [];
        for (let d = 0; d < this.deckCount; d++) {
            for (const suit of this.suits) {
                for (const rank of this.ranks) {
                    const color = (suit.name === 'hearts' || suit.name === 'diamonds') ? 'red' : 'black';
                    const file = `${rank.name}_of_${suit.name}.png`;
                    this.shoe.push({
                        suit: suit.symbol,
                        suitName: suit.name,
                        rank: rank.symbol,
                        rankName: rank.name,
                        value: rank.value,
                        color,
                        file
                    });
                }
            }
        }
        this.shuffleShoe();
    }

    shuffleShoe() {
        for (let i = this.shoe.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [this.shoe[i], this.shoe[j]] = [this.shoe[j], this.shoe[i]];
        }
    }

    drawCard() {
        if (this.shoe.length < 52) {
            this.initShoe();
        }
        return this.shoe.pop();
    }

    setChip(amount) {
        this.selectedChip = amount;
        this.playChip();
    }

    getChipFileForAmount(amount) {
        if (amount >= 25000) return 's_chip_04.png';
        if (amount >= 5000) return 's_chip_03.png';
        if (amount >= 1000) return 's_chip_02.png';
        if (amount >= 500) return 's_chip_01.png';
        return 's_chip_00.png';
    }

    placeBet(spotIndex) {
        if (this.gameState !== 'BETTING') return;
        if (this.localBalance < this.selectedChip) {
            this.showNotification("Insufficient balance!");
            return;
        }

        this.currentBets[spotIndex] += this.selectedChip;
        this.deductBalance(this.selectedChip);
        this.playChip();
        this.updateUI();
    }

    clearBets() {
        if (this.gameState !== 'BETTING') return;
        const totalRefund = this.currentBets[0] + this.currentBets[1] + this.currentBets[2];
        if (totalRefund > 0) {
            this.localBalance += totalRefund;
            this.currentBets = { 0: 0, 1: 0, 2: 0 };
            this.playChip();
            this.updateUI();
        }
    }

    doubleCurrentBets() {
        if (this.gameState !== 'BETTING') return;
        const totalCurrent = this.currentBets[0] + this.currentBets[1] + this.currentBets[2];
        if (totalCurrent === 0) return;
        if (this.localBalance < totalCurrent) {
            this.showNotification("Insufficient balance to 2X bet!");
            return;
        }

        this.deductBalance(totalCurrent);
        this.currentBets[0] *= 2;
        this.currentBets[1] *= 2;
        this.currentBets[2] *= 2;
        this.playChip();
        this.updateUI();
    }

    rebet() {
        if (this.gameState !== 'BETTING') return;
        const lastTotal = this.lastBets[0] + this.lastBets[1] + this.lastBets[2];
        if (lastTotal === 0) {
            this.showNotification("No previous bets to repeat!");
            return;
        }
        if (this.localBalance < lastTotal) {
            this.showNotification("Insufficient balance to Rebet!");
            return;
        }

        this.clearBets();
        this.currentBets = { ...this.lastBets };
        this.deductBalance(lastTotal);
        this.playChip();
        this.updateUI();
    }

    calculateHand(cards) {
        let total = 0;
        let aces = 0;
        for (const c of cards) {
            total += c.value;
            if (c.rank === 'A') aces++;
        }
        while (total > 21 && aces > 0) {
            total -= 10;
            aces--;
        }
        const isBlackjack = (cards.length === 2 && total === 21);
        const isBust = total > 21;
        return { total, isBlackjack, isBust, isSoft: aces > 0 };
    }

    async deal() {
        if (this.gameState !== 'BETTING') return;
        const active = [0, 1, 2].filter(i => this.currentBets[i] > 0);
        if (active.length === 0) {
            this.showNotification("Please place a bet on the table!");
            return;
        }

        this.lastBets = { ...this.currentBets };
        this.insuranceBets = { 0: 0, 1: 0, 2: 0 };
        this.activeSpots = active;
        this.currentTurnIndex = 0;
        this.playerHands = { 0: [], 1: [], 2: [] };
        this.dealerCards = [];
        this.dealerHoleHidden = true;
        this.gameState = 'DEALING';
        this.updateUI();

        // 1st card to each active player spot
        for (const spot of this.activeSpots) {
            await this.sleep(260);
            this.playerHands[spot].push(this.drawCard());
            this.playCardDeal();
            this.updateUI();
        }

        // 1st card to dealer
        await this.sleep(300);
        this.dealerCards.push(this.drawCard());
        this.playCardDeal();
        this.updateUI();

        // 2nd card to each active player spot
        for (const spot of this.activeSpots) {
            await this.sleep(260);
            this.playerHands[spot].push(this.drawCard());
            this.playCardDeal();
            this.updateUI();
        }

        // 2nd (hole) card to dealer
        await this.sleep(300);
        this.dealerCards.push(this.drawCard());
        this.playCardDeal();
        this.updateUI();

        // Check if dealer upcard is Ace -> Offer Insurance
        if (this.dealerCards[0].rank === 'A') {
            this.gameState = 'INSURANCE_OFFER';
            this.updateUI();
            return;
        }

        // Check Dealer 10-value card peek
        if (this.dealerCards[0].value === 10) {
            const dealerEval = this.calculateHand(this.dealerCards);
            if (dealerEval.isBlackjack) {
                await this.sleep(600);
                this.dealerHoleHidden = false;
                this.finishRound();
                return;
            }
        }

        this.startPlayerTurns();
    }

    resolveInsurance(accept) {
        if (this.gameState !== 'INSURANCE_OFFER') return;
        if (accept) {
            let totalIns = 0;
            for (const spot of this.activeSpots) {
                const insCost = Math.floor(this.currentBets[spot] / 2);
                if (this.localBalance >= insCost) {
                    this.deductBalance(insCost);
                    this.insuranceBets[spot] = insCost;
                    totalIns += insCost;
                }
            }
            if (totalIns > 0) this.playChip();
        }

        const dealerEval = this.calculateHand(this.dealerCards);
        if (dealerEval.isBlackjack) {
            this.dealerHoleHidden = false;
            for (const spot of this.activeSpots) {
                if (this.insuranceBets[spot] > 0) {
                    this.addBalance(this.insuranceBets[spot] * 3, this.insuranceBets[spot], true);
                }
            }
            this.finishRound();
        } else {
            this.startPlayerTurns();
        }
    }

    startPlayerTurns() {
        this.gameState = 'PLAYER_TURN';
        this.currentTurnIndex = 0;
        this.checkCurrentHand();
    }

    checkCurrentHand() {
        if (this.currentTurnIndex >= this.activeSpots.length) {
            this.dealerTurn();
            return;
        }

        const spot = this.activeSpots[this.currentTurnIndex];
        const hEval = this.calculateHand(this.playerHands[spot]);

        if (hEval.isBlackjack) {
            this.playBlackjack();
            this.nextTurn();
        } else if (hEval.isBust) {
            this.playBust();
            this.nextTurn();
        } else if (hEval.total === 21) {
            this.nextTurn();
        } else {
            this.updateUI();
        }
    }

    async hit() {
        if (this.gameState !== 'PLAYER_TURN') return;
        const spot = this.activeSpots[this.currentTurnIndex];
        this.playerHands[spot].push(this.drawCard());
        this.playCardDeal();
        this.updateUI();

        const hEval = this.calculateHand(this.playerHands[spot]);
        if (hEval.isBust || hEval.total === 21) {
            await this.sleep(600);
            this.checkCurrentHand();
        }
    }

    stand() {
        if (this.gameState !== 'PLAYER_TURN') return;
        this.playChip();
        this.nextTurn();
    }

    async doubleDown() {
        if (this.gameState !== 'PLAYER_TURN') return;
        const spot = this.activeSpots[this.currentTurnIndex];
        const hand = this.playerHands[spot];
        if (hand.length !== 2) return;

        const bet = this.currentBets[spot];
        if (this.localBalance < bet) {
            this.showNotification("Insufficient balance to Double Down!");
            return;
        }

        this.deductBalance(bet);
        this.currentBets[spot] *= 2;
        this.playChip();

        hand.push(this.drawCard());
        this.playCardDeal();
        this.updateUI();

        await this.sleep(700);
        this.nextTurn();
    }

    async split() {
        if (this.gameState !== 'PLAYER_TURN') return;
        const spot = this.activeSpots[this.currentTurnIndex];
        const hand = this.playerHands[spot];
        if (hand.length !== 2 || hand[0].value !== hand[1].value) return;

        const bet = this.currentBets[spot];
        if (this.localBalance < bet) {
            this.showNotification("Insufficient balance to Split!");
            return;
        }

        this.deductBalance(bet);
        this.playChip();

        hand.pop();
        hand.push(this.drawCard());
        this.playCardDeal();
        this.updateUI();
    }

    nextTurn() {
        this.currentTurnIndex++;
        if (this.currentTurnIndex >= this.activeSpots.length) {
            this.dealerTurn();
        } else {
            this.checkCurrentHand();
        }
    }

    async dealerTurn() {
        this.gameState = 'DEALER_TURN';
        this.dealerHoleHidden = false;
        this.playCardDeal();
        this.updateUI();

        let dealerEval = this.calculateHand(this.dealerCards);

        // Check if all player hands busted
        const allBusted = this.activeSpots.every(s => this.calculateHand(this.playerHands[s]).isBust);

        if (!allBusted) {
            // Dealer draws to 16, stands on 17
            while (dealerEval.total < 17) {
                await this.sleep(600);
                this.dealerCards.push(this.drawCard());
                this.playCardDeal();
                dealerEval = this.calculateHand(this.dealerCards);
                this.updateUI();
            }
        }

        await this.sleep(500);
        this.finishRound();
    }

    finishRound() {
        this.gameState = 'ROUND_OVER';
        const dealerEval = this.calculateHand(this.dealerCards);
        let roundWon = false;

        for (const spot of this.activeSpots) {
            const hand = this.playerHands[spot];
            const pEval = this.calculateHand(hand);
            const bet = this.currentBets[spot];

            if (pEval.isBust) {
                hand.result = 'BUST! LOSE';
                this.addBalance(0, bet, false);
            } else if (pEval.isBlackjack) {
                if (dealerEval.isBlackjack) {
                    hand.result = 'PUSH (TIE)';
                    this.addBalance(bet, bet, true);
                } else {
                    hand.result = 'BLACKJACK! 3:2';
                    const payout = Math.floor(bet * 2.5);
                    this.addBalance(payout, bet, true);
                    roundWon = true;
                }
            } else if (dealerEval.isBust) {
                hand.result = 'DEALER BUST! WIN';
                const payout = bet * 2;
                this.addBalance(payout, bet, true);
                roundWon = true;
            } else if (pEval.total > dealerEval.total) {
                hand.result = 'WINNER!';
                const payout = bet * 2;
                this.addBalance(payout, bet, true);
                roundWon = true;
            } else if (pEval.total < dealerEval.total) {
                hand.result = 'DEALER WINS';
                this.addBalance(0, bet, false);
            } else {
                hand.result = 'PUSH (TIE)';
                this.addBalance(bet, bet, true);
            }
        }

        if (roundWon) {
            this.playWin();
        }

        this.updateUI();
    }

    newRound() {
        this.gameState = 'BETTING';
        this.playerHands = { 0: [], 1: [], 2: [] };
        this.dealerCards = [];
        this.dealerHoleHidden = true;
        this.updateUI();
    }

    toggleCurrency() {
        this.currency = this.currency === 'PKR' ? 'USD' : 'PKR';
        this.updateUI();
    }

    formatMoney(val) {
        if (this.currency === 'PKR') {
            return `₨${Number(val).toLocaleString()}`;
        }
        return `$${Number(val).toLocaleString()}`;
    }

    showNotification(msg) {
        const toast = document.getElementById('bj-toast');
        if (toast) {
            toast.innerText = msg;
            toast.classList.add('show');
            setTimeout(() => toast.classList.remove('show'), 2500);
        }
    }

    sleep(ms) {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    updateUI() {
        // Balance
        const balEl = document.getElementById('bj-balance-val');
        if (balEl) balEl.innerText = this.formatMoney(this.localBalance);

        // Insurance Modal
        const insModal = document.getElementById('bj-insurance-modal');
        if (insModal) {
            insModal.style.display = this.gameState === 'INSURANCE_OFFER' ? 'flex' : 'none';
        }

        // Betting Spots
        for (let i = 0; i <= 2; i++) {
            const spotWrapper = document.getElementById(`bj-spot-${i}`);
            const chipStackEl = document.getElementById(`bj-spot-chip-${i}`);
            const betValEl = document.getElementById(`bj-spot-bet-${i}`);

            if (this.currentBets[i] > 0) {
                if (chipStackEl) {
                    chipStackEl.src = `${this.baseAssetPath}chips/${this.getChipFileForAmount(this.currentBets[i])}`;
                    chipStackEl.style.display = 'block';
                }
                if (betValEl) {
                    betValEl.innerText = this.formatMoney(this.currentBets[i]);
                    betValEl.style.display = 'block';
                }
            } else {
                if (chipStackEl) chipStackEl.style.display = 'none';
                if (betValEl) betValEl.style.display = 'none';
            }

            if (spotWrapper) {
                const isActive = this.gameState === 'PLAYER_TURN' && this.activeSpots[this.currentTurnIndex] === i;
                spotWrapper.classList.toggle('active-spot', isActive);
            }

            // Cards Rendering
            const cardsContainer = document.getElementById(`bj-cards-${i}`);
            if (cardsContainer) {
                cardsContainer.innerHTML = '';
                const cards = this.playerHands[i] || [];
                cards.forEach((card) => {
                    const cardImg = document.createElement('img');
                    cardImg.src = `${this.baseAssetPath}cards/${card.file}`;
                    cardImg.className = 'bj-card-img bj-card-animated';
                    cardImg.alt = `${card.rank} ${card.suit}`;
                    cardsContainer.appendChild(cardImg);
                });

                // Spot Total
                const totalEl = document.getElementById(`bj-total-${i}`);
                if (totalEl) {
                    if (cards.length > 0) {
                        const hEval = this.calculateHand(cards);
                        totalEl.innerText = hEval.total;
                        totalEl.style.display = 'inline-block';
                    } else {
                        totalEl.style.display = 'none';
                    }
                }

                // Spot Result Badge
                const resEl = document.getElementById(`bj-result-${i}`);
                if (resEl) {
                    if (cards.result) {
                        resEl.innerText = cards.result;
                        resEl.className = `bj-spot-result ${cards.result.includes('WIN') || cards.result.includes('BLACKJACK') ? 'win' : cards.result.includes('BUST') || cards.result.includes('LOSE') ? 'lose' : 'push'}`;
                        resEl.style.display = 'block';
                    } else {
                        resEl.style.display = 'none';
                    }
                }
            }
        }

        // Dealer Cards
        const dealerCardsEl = document.getElementById('bj-dealer-cards');
        if (dealerCardsEl) {
            dealerCardsEl.innerHTML = '';
            this.dealerCards.forEach((card, idx) => {
                const isHole = idx === 1 && this.dealerHoleHidden;
                const cardImg = document.createElement('img');
                cardImg.src = isHole ? `${this.baseAssetPath}cards/s_card_back.png` : `${this.baseAssetPath}cards/${card.file}`;
                cardImg.className = 'bj-card-img bj-card-animated';
                cardImg.alt = isHole ? 'Card Back' : `${card.rank} ${card.suit}`;
                dealerCardsEl.appendChild(cardImg);
            });

            // Dealer Score Pill
            const dealerScoreEl = document.getElementById('bj-dealer-score');
            if (dealerScoreEl) {
                if (this.dealerCards.length > 0) {
                    if (this.dealerHoleHidden) {
                        dealerScoreEl.innerText = this.dealerCards[0].value;
                    } else {
                        dealerScoreEl.innerText = this.calculateHand(this.dealerCards).total;
                    }
                    dealerScoreEl.style.display = 'inline-block';
                } else {
                    dealerScoreEl.style.display = 'none';
                }
            }
        }

        // Action Buttons visibility
        const isBetting = this.gameState === 'BETTING';
        const isPlayerTurn = this.gameState === 'PLAYER_TURN';
        const isRoundOver = this.gameState === 'ROUND_OVER';

        const btnDeal = document.getElementById('btn-deal');
        const btnClear = document.getElementById('btn-clear');
        const btnDoubleBet = document.getElementById('btn-double-bet');
        const btnRebet = document.getElementById('btn-rebet');
        const btnHit = document.getElementById('btn-hit');
        const btnStand = document.getElementById('btn-stand');
        const btnDouble = document.getElementById('btn-double');
        const btnSplit = document.getElementById('btn-split');
        const btnNewRound = document.getElementById('btn-newround');

        if (btnDeal) btnDeal.style.display = isBetting ? 'inline-flex' : 'none';
        if (btnClear) btnClear.style.display = isBetting ? 'inline-flex' : 'none';
        if (btnDoubleBet) btnDoubleBet.style.display = isBetting ? 'inline-flex' : 'none';
        if (btnRebet) btnRebet.style.display = isBetting ? 'inline-flex' : 'none';

        if (btnHit) btnHit.style.display = isPlayerTurn ? 'inline-flex' : 'none';
        if (btnStand) btnStand.style.display = isPlayerTurn ? 'inline-flex' : 'none';

        let canDouble = false;
        let canSplit = false;
        if (isPlayerTurn) {
            const spot = this.activeSpots[this.currentTurnIndex];
            const hand = this.playerHands[spot];
            if (hand && hand.length === 2) {
                canDouble = true;
                if (hand[0].value === hand[1].value) {
                    canSplit = true;
                }
            }
        }
        if (btnDouble) btnDouble.style.display = canDouble ? 'inline-flex' : 'none';
        if (btnSplit) btnSplit.style.display = canSplit ? 'inline-flex' : 'none';

        if (btnNewRound) btnNewRound.style.display = isRoundOver ? 'inline-flex' : 'none';

        // Chips rack interaction
        const chipsRack = document.getElementById('bj-chips-rack');
        if (chipsRack) {
            chipsRack.style.opacity = isBetting ? '1' : '0.4';
            chipsRack.style.pointerEvents = isBetting ? 'auto' : 'none';
        }
    }
}

window.pragmaticBlackjack = new PragmaticBlackjackEngine();
window.addEventListener('DOMContentLoaded', () => {
    window.pragmaticBlackjack.updateUI();
});
